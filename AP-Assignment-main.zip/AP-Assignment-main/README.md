# AP-Assignment 1
Question 1 - Extending Interface in Concrete Class
Question 2 - Differentiate functionality of DepositTransaction 
and WithdrawalTransaction 
Question 3 - Exception Handling and Client Codes
Question 4 - Writing the Client Code

files;
TransactionInterface.java
BaseTransaction.java
DepositTransaction.java
WithdrawalTransaction.java
InsufficientFundsException.java
BankAccount.java
Main.java
